./multi_rx.py -v 1 -c p25_rtl_example.json 2> stderr.2
