#include <vector>
typedef std::vector<bool> bit_vector;
int bchDec(bit_vector& Codeword);

