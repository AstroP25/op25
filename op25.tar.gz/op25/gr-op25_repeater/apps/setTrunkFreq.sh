#!/bin/sh
./cfgtrunk.py trunk.tsv 0.1 $1
